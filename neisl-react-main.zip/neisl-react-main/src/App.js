import { render } from "@testing-library/react";
import { Button } from "primereact/button";
import React from "react"
import { Router, Link } from "@reach/router"
import HeaderComponent from "./Components/HeaderComponent"
import './App.css';
import menubar from "./Components/MenubarComponent";
import MenubarComponent from "./Components/MenubarComponent";
import SplitButtonDemo from "./Components/UserComponent";
import FooterComponent from "./Components/FooterComponent";

const HomeComponent = React.lazy(() => import('./Components//Home'));
const UsersComponent = React.lazy(() => import('./Components/Users'));
const WireCentersComponent = React.lazy(() => import('./Components/WireCenters'));
const ToolsComponent = React.lazy(() => import('./Components/Tools'));
const ReportsComponent = React.lazy(() => import('./Components/Reports'));

function App() {
  return (
    <div className="page-container">
      <div className="content-wrap">
        <HeaderComponent />
        <MenubarComponent />
        <Router>
          <HomeComponent path="/" />
          <UsersComponent path="/users" />
          <WireCentersComponent path="/wirecenters" />
          <ToolsComponent path="/tools" />
          <ReportsComponent path="/reports" />
        </Router>
      </div>
      <FooterComponent />

    </div>
  );
}
export default App;
