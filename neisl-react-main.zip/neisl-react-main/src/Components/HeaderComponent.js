import React from "react";
import { SplitButton } from "primereact/splitbutton";
import SplitButtonDemo from "./UserComponent";
import "./index.css";
import UserComponent from "./UserComponent";

let HeaderComonent = () => {
  return (
    // <p style={{paddingLeft:'700px'}}>User name <i className="pi pi-angle-down"></i></p>
    <React.Fragment>
      <div className="container">
        <label className="logo">
          <img
            src="/images/Lumen_Technologies_logo.svg"
            alt="lumen logo"
            className="mr-4"
            height={20}
            width={150}
          ></img>
        </label>
        <h2 className="neisl">NEISL Inventory Automation</h2>
        <div
          className="userbutton"
          style={{ position: "absolute", right: "60px", top: "25px" }}
        >
          <UserComponent />
        </div>
      </div>
    </React.Fragment>
  );
};

export default HeaderComonent;
