import React from "react";
import { SplitButton } from "primereact/splitbutton";
import "primeicons/primeicons.css";
import { Link } from "react-router-dom";

import "./FooterComponent.css";

const FooterComponent = () => {
  const items = [
    {
      label: "Spanish",
    },
  ];

  return (
    <React.Fragment>
      <footer className="footerCls">
        <div className="footer-items" style={{ fontSize: "12px" }}>
          <div style={{ textAlign: "left", marginRight: "100px" }}>
            Site Version -v2
          </div>

          <div style={{ textAlign: "right" }}>
            &copy; 2021 Lumen Technologies. All Rights Reserved. Lumen is a
            registered trademark in the United States, EU and certain other
            countries
          </div>
        </div>
      </footer>
    </React.Fragment>
  );
};
export default FooterComponent;
