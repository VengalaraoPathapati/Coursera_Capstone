import React, { useState, useEffect } from 'react';
import { InputText } from 'primereact/inputtext';
import './index.css';
import './Users.css';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { PrimeIcons } from 'primereact/api';
import { DetailService } from '../service/DetailService';
const Users = () => {
    const [value1, setValue1] = useState('');
    const [value2, setValue2] = useState('');
    const [value3, setValue3] = useState('');
    const [value4, setValue4] = useState('');
    const [type, setType] = useState('User Type');
    const [type1, setType1] = useState('User Type');
    const [details, setDetails] = useState(null);
    const detailService = new DetailService();
    useEffect(() => {
        detailService.getDetails().then(data => setDetails(data));
    }, []);
    const handleTypeChange = (event) => {
        setType(event.target.value);
    };
    const handleType1Change = (event) => {
        setType1(event.target.value);
    };

    return (<div style={{ marginLeft: '65px' }}>

        <div className='iconclass'>

            <label><i className='pi pi-chevron-left' style={{ position: "relative", top: "10px" }}><a href="/" style={{ 'fontFamily': 'Inter', fontSize: '1.1rem' }} className='link'>Home</a></i></label>
        </div>
        <h2 style={{ position: "relative", bottom: "20px", top: "5px", color: "#083176", marginBottom: '62px' }}>Users</h2>
        <div class="input" style={{ position: "relative", bottom: "44px", marginBottom: '22px' }}>Assign Roles to Employees</div>
        <div class="card" style={{ position: "relative", bottom: "40px" }}>
            <InputText value={value1} onChange={(e) => setValue1(e.target.value)} placeholder="Enter CUID" /> &nbsp;&nbsp;
            <InputText value={value2} placeholder="Employee Name" disabled />&nbsp;&nbsp;
            <InputText value={value3} placeholder="Employee Email" disabled />&nbsp;&nbsp;
            <Dropdown Label="User Type"
                options={[
                    { label: 'User Type', value: 'User Type' },
                    { label: 'Admin', value: 'Admin' },
                    { label: 'Automation Admin', value: 'Automation Admin' },
                ]}
                value={type}
                onChange={handleTypeChange} />&nbsp;&nbsp;
            <Button label='Add User' />
        </div>
        <div class="input" style={{ position: "relative", bottom: "40px" }}>Employee Role Details</div>
        <div class="card2" style={{ position: "relative", bottom: "30px" }}>
            <span className="p-input-icon-right">
                <i className="pi pi-search" />
                <InputText value={value4} onChange={(e) => setValue1(e.target.value)} placeholder="Search" />
            </span> &nbsp;&nbsp;
            <Dropdown Label="User Type"
                options={[
                    { label: 'User Type', value: 'User Type' },
                    { label: 'Admin', value: 'Admin' },
                    { label: 'Automation Admin', value: 'Automation Admin' },
                    { label: 'All', value: 'All' },
                ]}
                value={type1}
                onChange={handleType1Change} />
            <div class="table">
                <DataTable value={details} stripedRows style={{ position: "relative", top: "28px", right: "22px", width: "1228px" }} >
                    <Column field="CUID" header="CUID"></Column>
                    <Column field="Name" header="Name"></Column>
                    <Column field="Email" header="Email"></Column>
                    <Column field="Role" header="Role"></Column>
                    <Column field="Action" header="Action"></Column>
                </DataTable>
            </div></div>
        <br /><br /><br /><br /><br /><br />



    </div>);

}

export default Users;