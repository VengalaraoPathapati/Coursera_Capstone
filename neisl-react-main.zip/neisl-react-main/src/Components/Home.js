import "./Home.css";
import "primeicons/primeicons.css";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.css";
import "primeflex/primeflex.css";

import ReactDOM from "react-dom";

import React, { useState, useEffect } from "react";
import { InputText } from "primereact/inputtext";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

const Home = () => {
  const [products, setProducts] = useState([]);

  return (
    <>
      <div
        className="unique"
        style={{
          backgroundImage: "url(/images/background-image1.png",
          height: "220px",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          marginLeft: "-18px",
          marginRight: "-18px",
          // filter: 'brightness(50%)',
        }}
      >
        <div className="center">
          <br />
          <br />
          <h2 style={{ marginTop: "0px", color: "white", fontSize: "29px" }}>
            Search Projects
          </h2>
          <span className="p-float-label p-input-icon-right">
            <i className="pi pi-search" />
            <InputText id="righticon" />
            <label htmlFor="righticon">Search</label>
          </span>
        </div>
      </div>

      <div>
        <div
          className="card"
          style={{
            width: "86%",
            marginLeft: "96px",
            marginRight: "60px",
            backgroundColor: "rgb(248, 249, 249)",
            paddingLeft: "52px",
            paddingTop: "3px",
            paddingBottom: "34px",
            marginTop: "-50px",
          }}
        >
          <b>
            <h4 style={{ color: "black" }}>Recently Viewed</h4>
          </b>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <tr style={{ backgroundColor: "white" }}>
              <td>
                <div>
                  <b>Project ID</b>
                </div>
                <div>N.800634</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>V4</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>Root</div>
              </td>
              <td>
                <div>
                  <b>Status</b>
                </div>
                <div>Engineering</div>
              </td>
              <td>
                <div>
                  <b>Issue Date</b>
                </div>
                <div>2/14/2022 9:38:18 PM</div>
              </td>
              <td>
                <div>
                  <b>Job Type</b>
                </div>
                <div>ADTRAN</div>
              </td>
              <td>
                <div>
                  <b>Work Type</b>
                </div>
                <div>QF</div>
              </td>
              <td>
                <div>
                  <b>Splitter Type</b>
                </div>
                <div>Dynamic</div>
              </td>
            </tr>
            <br />
            <tr style={{ backgroundColor: "white" }}>
              <td>
                <div>
                  <b>Project ID</b>
                </div>
                <div>N.800634</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>V4</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>Root</div>
              </td>
              <td>
                <div>
                  <b>Status</b>
                </div>
                <div>Engineering</div>
              </td>
              <td>
                <div>
                  <b>Issue Date</b>
                </div>
                <div>2/14/2022 9:38:18 PM</div>
              </td>
              <td>
                <div>
                  <b>Job Type</b>
                </div>
                <div>ADTRAN</div>
              </td>
              <td>
                <div>
                  <b>Work Type</b>
                </div>
                <div>QF</div>
              </td>
              <td>
                <div>
                  <b>Splitter Type</b>
                </div>
                <div>Dynamic</div>
              </td>
            </tr>
            <br />
            <tr style={{ backgroundColor: "white" }}>
              <td>
                <div>
                  <b>Project ID</b>
                </div>
                <div>N.800634</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>V4</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>Root</div>
              </td>
              <td>
                <div>
                  <b>Status</b>
                </div>
                <div>Engineering</div>
              </td>
              <td>
                <div>
                  <b>Issue Date</b>
                </div>
                <div>2/14/2022 9:38:18 PM</div>
              </td>
              <td>
                <div>
                  <b>Job Type</b>
                </div>
                <div>ADTRAN</div>
              </td>
              <td>
                <div>
                  <b>Work Type</b>
                </div>
                <div>QF</div>
              </td>
              <td>
                <div>
                  <b>Splitter Type</b>
                </div>
                <div>Dynamic</div>
              </td>
            </tr>

            <br />
            <tr style={{ backgroundColor: "white" }}>
              <td>
                <div>
                  <b>Project ID</b>
                </div>
                <div>N.800634</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>V4</div>
              </td>
              <td>
                <div>
                  <b>Version</b>
                </div>
                <div>Root</div>
              </td>
              <td>
                <div>
                  <b>Status</b>
                </div>
                <div>Engineering</div>
              </td>
              <td>
                <div>
                  <b>Issue Date</b>
                </div>
                <div>2/14/2022 9:38:18 PM</div>
              </td>
              <td>
                <div>
                  <b>Job Type</b>
                </div>
                <div>ADTRAN</div>
              </td>
              <td>
                <div>
                  <b>Work Type</b>
                </div>
                <div>QF</div>
              </td>
              <td>
                <div>
                  <b>Splitter Type</b>
                </div>
                <div>Dynamic</div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </>
  );
};

export default Home;
