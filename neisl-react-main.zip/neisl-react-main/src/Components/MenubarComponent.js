import React from 'react';
import { Menubar } from 'primereact/menubar';
import { InputText } from 'primereact/inputtext';

const MenubarComponent = () => {

    const items = [
        {
            label: 'Home',
            url: '/'
        },
        {


            label: 'Admin',
            items: [
                {
                    label: 'Wirecenters',
                    url: '/wirecenters'
                },
                {
                    label: 'Users',
                    url: '/users'
                }
            ]

        },
        {
            label: 'Automation Jobs',
            url: '/reports'
        },
        {
            label: 'ODiN Inventory Viewer',
            url: '/reports'
        }

    ]

    return (
        <React.Fragment>
            <Menubar model={items} className='text text-white' />
        </React.Fragment>

    )
};
export default MenubarComponent;
