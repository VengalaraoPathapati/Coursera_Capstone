import React, { useRef } from "react";
import { SplitButton } from "primereact/splitbutton";

const UserComponent = () => {
  const items = [
    {
      label: "Profile",
    },
  ];
  return (
    <div className="butt">
      <SplitButton
        label="User name"
        model={items}
        className="p-button-text mr-2 mb-2 p-button-plain"
      ></SplitButton>
    </div>
  );
};
export default UserComponent;
