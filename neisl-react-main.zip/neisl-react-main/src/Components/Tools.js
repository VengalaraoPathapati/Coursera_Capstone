const Tools = () => {
    return (<div>
        Tools
    </div>);
}
 
export default Tools;