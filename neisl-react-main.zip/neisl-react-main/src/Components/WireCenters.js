import "primeicons/primeicons.css";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.css";
import "primeflex/primeflex.css";

import ReactDOM from "react-dom";

import React, { useState, useEffect } from "react";
import { InputSwitch } from "primereact/inputswitch";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { MultiSelect } from "primereact/multiselect";
import { CustomerService } from "../service/CustomerService";

import "./index.css";
import "./WireCenters.css";

const WireCenters = () => {
  const [checked1, setChecked1] = useState(true);
  const [wirecenters1, setwirecenters1] = useState(null);
  const [myArrayFiltered, setmyArrayFiltered] = useState(null);
  const [totalResults, setTotalResults] = useState(null);

  const states = [
    {
      name: "Alabama",
      abbreviation: "AL",
    },
    {
      name: "Arkansas",
      abbreviation: "AR",
    },
    {
      name: "Arizona",
      abbreviation: "AZ",
    },
    {
      name: "California",
      abbreviation: "CA",
    },
    {
      name: "Colorado",
      abbreviation: "CO",
    },
    {
      name: "Florida",
      abbreviation: "FL",
    },
    {
      name: "Georgia",
      abbreviation: "GA",
    },
    {
      name: "Iowa",
      abbreviation: "IA",
    },
    {
      name: "Idaho",
      abbreviation: "ID",
    },
    {
      name: "Illinois",
      abbreviation: "IL",
    },
    {
      name: "Indiana",
      abbreviation: "IN",
    },
    {
      name: "Kansas",
      abbreviation: "KS",
    },
    {
      name: "Louisiana",
      abbreviation: "LA",
    },
    {
      name: "Maryland",
      abbreviation: "MD",
    },
    {
      name: "Michigan",
      abbreviation: "MI",
    },
    {
      name: "Minnesota",
      abbreviation: "MN",
    },
    {
      name: "Missouri",
      abbreviation: "MO",
    },
    {
      name: "Mississippi",
      abbreviation: "MS",
    },
    {
      name: "Montana",
      abbreviation: "MT",
    },
    {
      name: "North Carolina",
      abbreviation: "NC",
    },
    {
      name: "North Dakota",
      abbreviation: "ND",
    },
    {
      name: "Nebraska",
      abbreviation: "NE",
    },
    {
      name: "New Jersey",
      abbreviation: "NJ",
    },
    {
      name: "New Mexico",
      abbreviation: "NM",
    },
    {
      name: "Nevada",
      abbreviation: "NV",
    },
    {
      name: "Ohio",
      abbreviation: "OH",
    },
    {
      name: "Oklahoma",
      abbreviation: "OK",
    },
    {
      name: "Oregon",
      abbreviation: "OR",
    },
    {
      name: "Pennsylvania",
      abbreviation: "PA",
    },
    {
      name: "South Carolina",
      abbreviation: "SC",
    },
    {
      name: "South Dakota",
      abbreviation: "SD",
    },
    {
      name: "Tennessee",
      abbreviation: "TN",
    },
    {
      name: "Texas",
      abbreviation: "TX",
    },
    {
      name: "Utah",
      abbreviation: "UT",
    },
    {
      name: "Virginia",
      abbreviation: "VA",
    },
    {
      name: "Washington",
      abbreviation: "WA",
    },
    {
      name: "Wisconsin",
      abbreviation: "WI",
    },
    {
      name: "Wyoming",
      abbreviation: "WY",
    },
  ];

  const [selectedStates, setSelectedStates] = useState(null);

  const [filters1, setFilters1] = useState(null);
  const [filters2, setFilters2] = useState({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    state: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    wirecenter: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    status: { value: null, matchMode: FilterMatchMode.EQUALS },
  });
  const [globalFilterValue1, setGlobalFilterValue1] = useState("");

  const [loading1, setLoading1] = useState(true);

  const customerService = new CustomerService();

  useEffect(() => {
    customerService.getWirecentersLarge().then((data) => {
      setwirecenters1(data);
      setLoading1(false);
    });
    initFilters1();
  }, []);

  useEffect(() => {
    if (selectedStates) {
      var myArrayFiltered = wirecenters1.filter((el) => {
        return selectedStates.some((f) => {
          return f.name === el.state;
        });
      });
      setmyArrayFiltered(myArrayFiltered);
    }
  }, [selectedStates]);

  const clearFilter1 = () => {
    initFilters1();
  };

  const onGlobalFilterChange1 = (e) => {
    const value = e.target.value;
    let _filters1 = { ...filters1 };
    _filters1["global"].value = value;
    setFilters1(_filters1);
    setGlobalFilterValue1(value);
    setSelectedStates(null);
  };

  const onGlobalMultiFilter = async (e) => {
    if (e.value.length) setSelectedStates(e.value);
    else setSelectedStates(null);
  };

  const initFilters1 = () => {
    setFilters1({
      global: { value: null, matchMode: FilterMatchMode.CONTAINS },
      state: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      wirecenter: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      "country.name": {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      representative: { value: null, matchMode: FilterMatchMode.IN },
      date: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
      },
      balance: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      // 'status': { operator: FilterOperator.OR, constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }] },
      activity: { value: null, matchMode: FilterMatchMode.BETWEEN },
      status: { value: null, matchMode: FilterMatchMode.EQUALS },
    });
    setGlobalFilterValue1("");
  };
  const statesTemplate = (option) => {
    return (
      <div className="country-item">
        <div>{option.name}</div>
      </div>
    );
  };

  const selectedStatesTemplate = (option) => {
    const totalItems = selectedStates;
    const totalLength = totalItems ? totalItems.length : 0;
    if (totalLength < 5) {
      if (option) {
        return <span>{option.name}, </span>;
      }
    } else {
      return "";
    }
    return "Filter States";
  };
  const panelFooterTemplate = () => {
    const selectedItems = selectedStates;
    const length = selectedItems ? selectedItems.length : 0;

    return (
      <div className="py-2 px-3">
        <b>{length}</b> item{length > 1 ? "s" : ""} selected.
      </div>
    );
  };

  const renderHeader1 = () => {
    return (
      <React.Fragment>
        <div className="flex justify-content-between">
          {/* <Button type="button" icon="pi pi-filter-slash" label="Clear" className="p-button-outlined" onClick={clearFilter1} /> */}
          <span className="p-input-icon-left">
            <i className="pi pi-search" />
            <InputText
              value={globalFilterValue1}
              onChange={onGlobalFilterChange1}
              placeholder="Search"
            />
            &nbsp;
            <span className="multiselect-demo">
              {/* <MultiSelect value={selectedStates} options={states} onChange={updateTable} optionLabel="name" placeholder="Filter States" filter className="multiselect-custom"
                                itemTemplate={statesTemplate} selectedItemTemplate={selectedStatesTemplate} panelFooterTemplate={panelFooterTemplate} /> */}
              <MultiSelect
                value={selectedStates}
                options={states}
                onChange={onGlobalMultiFilter}
                optionLabel="name"
                placeholder="Filter States"
                filter
                className="multiselect-custom"
                itemTemplate={statesTemplate}
                selectedItemTemplate={selectedStatesTemplate}
                panelFooterTemplate={panelFooterTemplate}
              />
            </span>
          </span>
        </div>
        <br />
        <div
          style={{
            width: "1175px",
            height: "48px",
            backgroundColor: "#aedeff",
            marginLeft: "-13px",
            marginBottom: "-14px",
            marginTop: "-13px",
          }}
        >
          <div
            id="searchcontent"
            style={{
              fontSize: "14px",
              paddingTop: "13px",
              paddingLeft: "20px",
            }}
          >
            Search + Filtered Results (1-20 of 3810)
          </div>
        </div>
      </React.Fragment>
    );
  };
  const verifiedBodyTemplate = (rowData) => {
    if (checked1 == true)
      return (
        <InputSwitch checked={checked1} onChange={(e) => setChecked1(false)} />
      );
    else
      return (
        <InputSwitch checked={checked1} onChange={(e) => setChecked1(true)} />
      );
  };

//   const DataTable = (props) => {
//     console.log(props.currentPageReportTemplate);
//   };
  const header1 = renderHeader1();
  return (
    <div className="datatable-filter-demo">
      <div className="card">
        <br />
        <div style={{ marginLeft: "70px" }}>
          <div className="iconclass">
            <label>
              <i className="pi pi-chevron-left">
                <a
                  href="/"
                  className="link"
                  style={{ fontFamily: "Inter", fontSize: "1.1rem" }}
                >
                  Home
                </a>
              </i>
            </label>
          </div>
          <h2
            style={{
              fontWeight: "bolder",
              position: "relative",
              bottom: "20px",
              top: "5px",
              color: "#083176",
            }}
          >
            Wirecenters
          </h2>
        </div>
        <DataTable
          stripedRows
          style={{
            width: "1305px",
            marginLeft: "10px",
            paddingLeft: "64px",
            paddingRight: "64px",
          }}
          value={selectedStates ? myArrayFiltered : wirecenters1}
          paginator
          paginatorTemplate="RowsPerPageDropdown CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink"
          currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
          rows={10}
          rowsPerPageOptions={[10, 20, 50, 100]}
          className="p-datatable-customers"
          showGridlines
          dataKey="id"
          filters={filters1}
          filterDisplay="menu"
          loading={loading1}
          responsiveLayout="scroll"
          globalFilterFields={[
            "state",
            "wirecenter",
            "country.name",
            "balance",
            "status",
          ]}
          header={header1}
          emptyMessage="No data found."
        >
          <Column field="state" header="State" style={{ minWidth: "10rem" }} />
          <Column
            field="wirecenter"
            header="Wirecenter"
            style={{ minWidth: "17rem" }}
          />
          <Column
            field="status"
            header="Status"
            style={{ minWidth: "50rem" }}
            body={verifiedBodyTemplate}
          />
        </DataTable>
      </div>
    </div>
  );
};

export default WireCenters;
