import { applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import reducers from './rootReducer';

import { configureStore } from '@reduxjs/toolkit'

const store = configureStore(
    {reducer:reducers},applyMiddleware(thunk))

export default store