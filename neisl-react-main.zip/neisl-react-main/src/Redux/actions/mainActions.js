import { TEST_ACTION } from "../types";

export const onClickAction = (status) => ({
    type: TEST_ACTION,
    status
});