import { TEST_ACTION } from "../types";

let dataState = {
    status: false
};

const mainReducer = (state = dataState, action) => {
    switch (action.type) {
        case TEST_ACTION:
            return {...state, status: action.status};
        default:
            return state;
    }
};

export default mainReducer