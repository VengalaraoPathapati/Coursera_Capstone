import { combineReducers } from 'redux'
import mainReducer from './reducers/mainReducer'

const reducers = {
	mainReducer: mainReducer
}

export default combineReducers(reducers)