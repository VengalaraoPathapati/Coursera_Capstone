export class DetailService{
    getDetails() {
        return fetch('data/UseDetails.json').then(res => res.json())
            .then(d => d.data);
    }
}